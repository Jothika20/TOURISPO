<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '','tour');

// get the post records

$NAME = $_POST['NAME'];

$ADDRESS = $_POST['ADDRESS'];
$Day = $_POST['Day'];
$PLACE=$_POST['PLACE'];
$PHONE = $_POST['PHONE'];
$EMAIL = $_POST['EMAIL'];
$GENDER = $_POST['GENDER'];
$AGE = $_POST['AGE'];

// database insert SQL code
$sql = "INSERT INTO TOUR (fldNAME,fldADDRESS,fldDAY,fldPLACE,fldPHONE,fldEMAIL,fldGENDER,
fldAGE) VALUES (
    '$NAME', '$ADDRESS','$Day', '$PLACE', '$PHONE','$EMAIL','$GENDER','$AGE')";


$rs = mysqli_query($con, $sql);


echo nl2br("TOUR'S DETAILS ARE SAVED SUCESSFULLY         \n             HAPPY JOURNEY!!!");



// insert in database 
?>